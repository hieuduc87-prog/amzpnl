# Amazon P&L Simulator

Công cụ tính toán Profit & Loss cho sản phẩm Amazon FBA.

## Tính năng
- Tính tự động: Profit, Margin, Basecost/Revenue
- Ads mặc định 25% revenue, có thể chỉnh từng SP
- So sánh trực quan giữa các sản phẩm
- Nhân bản SP để test nhiều kịch bản giá
